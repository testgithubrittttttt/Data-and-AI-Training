from pydantic import BaseSettings

class Settings(BaseSettings):
    OPENROUTER_API_KEY: str
    OPENROUTER_URL: str = "https://openrouter.ai/api/v1/chat/completions"
    HTTP_REFERER: str = "http://localhost:8501"

    class Config:
        env_file = "../../.env"  # reads from root .env file

settings = Settings()
