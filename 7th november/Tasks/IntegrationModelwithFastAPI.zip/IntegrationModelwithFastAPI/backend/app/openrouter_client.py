import httpx
from backend.app.config import settings
from typing import List, Dict

async def call_openrouter(messages: List[Dict[str, str]], model: str = "mistralai/mistral-7b-instruct") -> str:
    headers = {
        "Authorization": f"Bearer {settings.OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": settings.HTTP_REFERER,
    }

    payload = {"model": model, "messages": messages}

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(settings.OPENROUTER_URL, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

    # Extract model response
    try:
        return data["choices"][0]["message"]["content"]
    except Exception:
        return str(data)
