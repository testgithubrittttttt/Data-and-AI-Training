from fastapi import APIRouter, HTTPException
from .schemas import AskRequest, AskResponse
from .openrouter_client import call_openrouter
from backend.app.openrouter_client import call_openrouter

router = APIRouter()

@router.post("/ask", response_model=AskResponse)
async def ask(request: AskRequest):
    messages = [
        {"role": "system", "content": "You are a helpful assistant that explains topics clearly."},
        {"role": "user", "content": f"Topic: {request.topic or 'General'}\nQuestion: {request.question}"}
    ]

    try:
        answer = await call_openrouter(messages)
        return AskResponse(answer=answer, model="mistralai/mistral-7b-instruct")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
