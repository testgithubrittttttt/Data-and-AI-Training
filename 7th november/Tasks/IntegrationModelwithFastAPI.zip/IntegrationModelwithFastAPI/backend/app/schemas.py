from pydantic import BaseModel
from typing import Optional

class AskRequest(BaseModel):
    topic: Optional[str] = None
    question: str

class AskResponse(BaseModel):
    answer: str
    model: Optional[str] = None
