import streamlit as st
import requests

st.set_page_config(page_title="Integration Model with FastAPI")
st.title("Ask the AI Model (via OpenRouter + FastAPI)")

backend_url = "http://localhost:8000/api/ask"

topic = st.text_input("Topic (optional)")
question = st.text_area("Your Question:")

if st.button("Get Answer"):
    if not question.strip():
        st.warning("Please enter a question first.")
    else:
        st.info("Processing your request...")
        try:
            res = requests.post(backend_url, json={"topic": topic or None, "question": question})
            if res.status_code == 200:
                st.success("Response received:")
                st.write(res.json().get("answer"))
            else:
                st.error(f"Error: {res.text}")
        except Exception as e:
            st.error(f"Failed to connect to backend: {e}")
